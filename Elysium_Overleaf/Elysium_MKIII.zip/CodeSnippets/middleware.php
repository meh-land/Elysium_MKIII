Route::middleware(['auth:api'])->group(function () {
    // define routes here
});